
<!DOCTYPE html>
<html lang="vi">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>[ Nguyễn Nhật Lộc ]</title>
        <link href="/assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <meta content="Thông Tin Thanh Toán !" property="og:title" />
        <meta content="https://profile.sieuthicode.net" property="og:url" />
        <meta content="" property="og:image" />
        <meta content="website" property="og:type" />

        <link rel="stylesheet" type="text/css" href="/assets/styles/style.css?ver=2.1" />
    </head>

    <body>
        <div class="snowflake"><img src="/assets/img/hoamai.svg"/></div>
        <div class="snowflake"><img src="/assets/img/hoadao.png"/></div>
        <div class="snowflake"><img src="/assets/img/hoamai.svg"/></div>
        <div class="snowflake"><img src="/assets/img/hoadao.png"/></div>
        <div class="snowflake"><img src="/assets/img/hoamai.svg"/></div>
        <div class="snowflake"><img src="/assets/img/hoadao.png"/></div>
        <div class="snowflake"><img src="/assets/img/hoamai.svg"/></div>
        <div class="snowflake"><img src="/assets/img/hoadao.png"/></div>
        <div class="snowflake"><img src="/assets/img/hoamai.svg"/></div>

        <!-- Preloader -->
        <div class="preloader">
            <div class="preloader__wrap">
                <div class="circle-pulse">
                    <div class="circle-pulse__1"></div>
                    <div class="circle-pulse__2"></div>
                </div>
                <div class="preloader__progress"><span></span></div>
            </div>
        </div>

        <main class="main">
            <!-- Header Image -->
            <div class="header-image">
                <div class="js-parallax" style="background-image: url(/assets/img/profile.jpg);"></div>
            </div>

            <div class="container gutter-top">
                <!-- Header -->
                <header class="header box">
                    <div class="header__left">
                        <div class="header__photo">
                            <img class="header__photo-img" src="/assets/img/avt.jpg" />
                        </div>
                        <div class="header__base-info">
                            <h2 class="title titl--h1 Ubuntu">
                                <b>Nguyễn Nhật Lộc<img src="/assets/img/tich-xanh.png" style="height: 24px;" /></b>
                            </h2>
                            <div class="skill-item" style="color: #ef9d64;"><b>Developer - PHP</b></div>
                            <ul class="header__social">
                                <li>
                                    <a href="https://www.facebook.com/nguyennhatloc/"><i class="fab fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="//zalo.me/0978364572"><i class="fas fa-phone"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="header__right">
                        <ul class="header__contact">
                            <li><span class="overhead">Email</span>cskh.sieuthicode@gmail.com</li>
                            <li><span class="overhead">Phone</span>036.5157.038</li>
                        </ul>
                        <ul class="header__contact">
                            <li><span class="overhead">Website</span>sieuthicode.net</li>
                            <li><span class="overhead">Location</span>Bình Dương, Việt Nam</li>
                        </ul>
                    </div>
                </header>

                <div class="row sticky-parent">
                    <!-- Sidebar nav -->

                    <!-- Content -->
                    <div class="col-12">
                        <div class="box box-content">
                            <!-- What -->
                            <div class="mt-1">
                                <h3 class="title title--h2 first-title title__separate">THÔNG TIN THANH TOÁN</h3>
                                <div class="row">
                                    <!-- Case Item -->
                                    <div class="col-12 col-lg-6">
                                        <div class="case-item">
                                            <img src="/assets/img/tsr.png" height="55px" />
                                            <div>
                                                &nbsp;
                                                <h4 class="title title--h4">Thẻ Siêu Rẻ</h4>
                                                <p>
                                                    <b>Nguyễn Nhật Lộc</b><br />
                                                    <b id="tsr">0978364572</b>
                                                </p>
                                                <button type="button" class="btn btn-primary btn-copy" onclick="copyToClipboard('#tsr')">COPY</button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Case Item -->
                                    <div class="col-12 col-lg-6">
                                        <div class="case-item">
                                            <img src="/assets/img/mbbank.png" height="55px" />
                                            <div>
                                                &nbsp;
                                                <h4 class="title title--h4">MB Bank</h4>
                                                <p>
                                                    <b>Nguyễn Nhật Lộc</b><br />
                                                    <b id="mbbank">28023456777888</b>
                                                </p>
                                                <button type="button" class="btn btn-primary btn-copy" onclick="copyToClipboard('#mbbank')">COPY</button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Case Item -->
                                    <div class="col-12 col-lg-6">
                                        <div class="case-item">
                                            <img src="/assets/img/momo.png" height="55px" />
                                            <div>
                                                &nbsp;
                                                <h4 class="title title--h4">Ví Momo</h4>
                                                <p>
                                                    <b>Nguyễn Nhật Lộc</b><br />
                                                    <b id="momo">0365157038</b>
                                                </p>
                                                <button type="button" class="btn btn-primary btn-copy" onclick="copyToClipboard('#momo')">COPY</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <div class="case-item">
                                            <img src="/assets/img/pay.png" height="55px" />
                                            <div>
                                                &nbsp;
                                                <h4 class="title title--h4">Zalo Pay</h4>
                                                <p>
                                                    <b>Nguyễn Nhật Lộc</b><br />
                                                    <b id="pay">0978364572</b>
                                                </p>
                                                <button type="button" class="btn btn-primary btn-copy" onclick="copyToClipboard('#pay')">COPY</button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Case Item -->
                                </div>
                                <center>
                                    <input type="checkbox" class="checkbox" id="checkbox" value="yes">
                                    <label for="checkbox" class="label-check">
                                      <i class="fas fa-moon"></i>
                                      <i class='fas fa-sun'></i>
                                      <div class='ball'>
                                    </label>
                                </center>
                            </div>

                        </div>
                         <center class="mt-2"><audio controls autoplay loop>
                             <source src="/assets/audio/Nhac-chuong-tam-giac-la-tac-giam-remix-tiktok.mp3"></source>
                        </audio></center>
                        <!-- Footer -->
                        <footer class="footer">
                            © 2022 Vận Hành Bởi SIEUTHICODE.NET
                        </footer>
                    </div>
                </div>
            </div>
        </main>
        <!-- JavaScripts -->
        <script src="/assets/js/jquery-3.4.1.min.js"></script>
        <script src="/assets/js/script.js"></script>
        <script src="/assets/js/sweetalert2.all.min.js"></script>
        <script src="/assets/js/plugins.min.js"></script>
        <script src="/assets/js/common.js"></script>
    </body>
</html>
